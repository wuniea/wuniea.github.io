//程序核心
//这里只是测试用，实际上是界面进行调用的
#include <iostream>
using namespace std;

#include <Main.h>


int main()
{
    //初始化
    //加载规则
    //加载存档
    //运行游戏核心
    Core core;
    core.Init();
    core.Start();
    return 0;
}