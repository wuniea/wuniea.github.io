#ifndef __Main.h__
#define __Main.h__

#include <String>
#include <vector>
#include <fstream>
//
#include <Ruler.cpp>
#include <SaveData.cpp>
#include <WorkCore.cpp>

#endif

