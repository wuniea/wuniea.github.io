//数据记录

//记录
class Ruler:public Data{};

//记录集
class Rulers:public Datas{};