//规则，也只是数据的一种

//规则
class Ruler:public Data{};

//规则集
class Rulers:public Datas{};