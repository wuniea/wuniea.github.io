//万物皆数据

//数据
class Data
{
    public:
        string name;
        string value;
        string state;
};

//数据集
class Datas
{
    public:
        vector<Data> datas;
};